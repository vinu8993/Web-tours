Action()
{

	/* 1. Navigate to webtours home page */

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("index.htm", 
		"URL=http://localhost:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/* 2. Click Sign up now */

	lr_think_time(8);

	web_link("sign up now", 
		"Text=sign up now", 
		"Snapshot=t2.inf", 
		LAST);

	/* 3. Enter profile details and click continue */

	lr_think_time(12);

	web_submit_form("login.pl", 
		"Snapshot=t3.inf", 
		ITEMDATA, 
		"Name=username", "Value={P_username}", ENDITEM, 
		"Name=password", "Value={P_password}", ENDITEM, 
		"Name=passwordConfirm", "Value={P_password}", ENDITEM, 
		"Name=firstName", "Value={P_username}", ENDITEM, 
		"Name=lastName", "Value={P_username}", ENDITEM, 
		"Name=address1", "Value=Piler", ENDITEM, 
		"Name=address2", "Value=AP", ENDITEM, 
		"Name=register.x", "Value=85", ENDITEM, 
		"Name=register.y", "Value=8", ENDITEM, 
		LAST);

	/* 4. Click continue to Login */

	lr_think_time(22);

	web_image("button_next.gif", 
		"Src=/WebTours/images/button_next.gif", 
		"Snapshot=t4.inf", 
		LAST);

	/* 5. Logout */

	lr_think_time(9);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t5.inf", 
		LAST);

	return 0;
}